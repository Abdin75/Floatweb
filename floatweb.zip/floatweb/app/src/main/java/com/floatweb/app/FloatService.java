package com.floatweb.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A floating, movable, resizable browser window (overlay) with an address bar that can be
 * shown or hidden, and a minimize-to-bubble mode. No libraries: framework classes only.
 */
public class FloatService extends Service {

    static final String ACTION_STOP = "com.floatweb.app.STOP";
    private static final String CHANNEL_ID = "floatweb";
    private static final String HOME_URL = "https://claude.ai/";
    private static final int NOT_FOCUSABLE = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    private static final int HW_ACCEL = WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    private Context ui;
    private WindowManager wm;
    private InputMethodManager imm;
    private float dp;

    private FrameLayout root;
    private LinearLayout col;
    private LinearLayout urlArea;
    private EditText urlField;
    private TextView urlToggle;
    private TextView renderButton;
    private WebView web;
    private WindowManager.LayoutParams lp;
    private boolean softwareRender = false;

    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private boolean minimized = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(1, buildNotification());
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (root == null) {
            createWindow();
        }
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL_ID, "FloatWeb", NotificationManager.IMPORTANCE_MIN));
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("FloatWeb is running")
                .setContentText("Tap to close it")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    // ------------------------------------------------------------------ window

    private void createWindow() {
        ui = new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        dp = getResources().getDisplayMetrics().density;

        // Root container. It also watches taps outside the window to give focus back.
        root = new FrameLayout(ui) {
            @Override
            public boolean dispatchTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                    setWindowFocusable(false);
                }
                return super.dispatchTouchEvent(e);
            }
        };
        root.setBackgroundColor(0xFF1F1F1F);

        col = new LinearLayout(ui);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        col.addView(buildBar(), new LinearLayout.LayoutParams(MATCH, (int) (40 * dp)));
        urlArea = buildUrlArea();
        urlArea.setVisibility(View.GONE);
        col.addView(urlArea, new LinearLayout.LayoutParams(MATCH,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        web = buildWebView();
        col.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        root.addView(buildResizeHandle(), new FrameLayout.LayoutParams(
                (int) (32 * dp), (int) (32 * dp), Gravity.BOTTOM | Gravity.END));

        DisplayMetrics m = getResources().getDisplayMetrics();
        lp = new WindowManager.LayoutParams(
                (int) (m.widthPixels * 0.92f),
                (int) (m.heightPixels * 0.45f),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | HW_ACCEL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (m.widthPixels * 0.04f);
        lp.y = 0;
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        wm.addView(root, lp);
        web.loadUrl(HOME_URL);
    }

    private WebView buildWebView() {
        WebView w = new WebView(ui);
        w.setBackgroundColor(0xFF1F1F1F);
        if (softwareRender) {
            w.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String scheme = r.getUrl().getScheme();
                boolean isWeb = "https".equals(scheme) || "http".equals(scheme);
                if (!isWeb) {
                    return true; // ignore other schemes
                }
                String host = r.getUrl().getHost();
                if (host != null && host.endsWith("accounts.google.com")) {
                    toast("Google blocks sign-in inside app windows like this one. "
                            + "Use 'Continue with email' instead.");
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                showUrl(url);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                showUrl(url);
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    toast("Page error: " + e.getDescription());
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                // The page process died (often low memory). Rebuild the view instead of crashing.
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        replaceWebView();
                    }
                });
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient());
        w.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    setWindowFocusable(true);
                }
                return false;
            }
        });
        return w;
    }

    private void replaceWebView() {
        if (col == null || web == null) {
            return;
        }
        col.removeView(web);
        web.destroy();
        web = buildWebView();
        col.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        web.loadUrl(HOME_URL);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ bars

    private LinearLayout buildBar() {
        LinearLayout bar = new LinearLayout(ui);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF263238);

        TextView title = new TextView(ui);
        title.setText("  FloatWeb");
        title.setTextColor(0xFFB0BEC5);
        title.setTextSize(12);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        ox = lp.x;
                        oy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        DisplayMetrics m = getResources().getDisplayMetrics();
                        lp.x = clamp(ox + (int) (e.getRawX() - sx), 0, m.widthPixels - lp.width);
                        lp.y = clamp(oy + (int) (e.getRawY() - sy), 0, m.heightPixels - lp.height);
                        wm.updateViewLayout(root, lp);
                        return true;
                    }
                    default:
                        return true;
                }
            }
        });
        bar.addView(title, new LinearLayout.LayoutParams(0, MATCH, 1f));

        bar.addView(button("<", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (web.canGoBack()) {
                    web.goBack();
                }
            }
        }));
        bar.addView(button("KB", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showKeyboardFor(web);
            }
        }));
        urlToggle = button("URL", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleUrlArea();
            }
        });
        bar.addView(urlToggle);
        bar.addView(button("\u2014", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                minimize();
            }
        }));
        bar.addView(button("X", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        }));
        return bar;
    }

    /** Second bar: address field + Go, and a row of tools. Shown/hidden with the URL button. */
    private LinearLayout buildUrlArea() {
        LinearLayout area = new LinearLayout(ui);
        area.setOrientation(LinearLayout.VERTICAL);
        area.setBackgroundColor(0xFF1C262B);

        LinearLayout row1 = new LinearLayout(ui);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER_VERTICAL);

        urlField = new EditText(ui);
        urlField.setSingleLine(true);
        urlField.setTextSize(13);
        urlField.setTextColor(0xFFFFFFFF);
        urlField.setHint("address or search");
        urlField.setHintTextColor(0xFF90A4AE);
        urlField.setBackgroundColor(0xFF263238);
        urlField.setPadding((int) (10 * dp), 0, (int) (10 * dp), 0);
        urlField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlField.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlField.setSelectAllOnFocus(true);
        urlField.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    showKeyboardFor(urlField);
                }
                return false;
            }
        });
        urlField.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent ev) {
                goToField();
                return true;
            }
        });
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(0, (int) (38 * dp), 1f);
        fp.setMargins((int) (4 * dp), (int) (3 * dp), (int) (2 * dp), (int) (3 * dp));
        row1.addView(urlField, fp);
        TextView go = button("Go", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToField();
            }
        });
        row1.addView(go, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, (int) (38 * dp)));
        area.addView(row1, new LinearLayout.LayoutParams(MATCH, (int) (44 * dp)));

        LinearLayout row2 = new LinearLayout(ui);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(tool("Home", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                web.loadUrl(HOME_URL);
            }
        }));
        row2.addView(tool("Reload", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                web.reload();
            }
        }));
        row2.addView(tool("Link", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadLinkFromClipboard();
            }
        }));
        renderButton = tool("GPU", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRender();
            }
        });
        row2.addView(renderButton);
        area.addView(row2, new LinearLayout.LayoutParams(MATCH, (int) (34 * dp)));
        return area;
    }

    private void toggleUrlArea() {
        boolean show = urlArea.getVisibility() != View.VISIBLE;
        urlArea.setVisibility(show ? View.VISIBLE : View.GONE);
        urlToggle.setTextColor(show ? 0xFFFFB300 : 0xFFFFFFFF);
        if (show) {
            showUrl(web.getUrl());
        } else {
            urlField.clearFocus();
            imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        }
    }

    private void showUrl(String url) {
        if (urlField != null && url != null && !urlField.hasFocus()) {
            urlField.setText(url);
        }
    }

    private void goToField() {
        String s = urlField.getText().toString().trim();
        if (s.length() == 0) {
            return;
        }
        String url;
        if (s.startsWith("https://")) {
            url = s;
        } else if (s.startsWith("http://")) {
            url = "https://" + s.substring(7);
        } else if (s.contains(" ") || !s.contains(".")) {
            url = "https://duckduckgo.com/?q=" + Uri.encode(s);
        } else {
            url = "https://" + s;
        }
        web.loadUrl(url);
        urlField.clearFocus();
        imm.hideSoftInputFromWindow(urlField.getWindowToken(), 0);
    }

    private TextView button(String label, View.OnClickListener l) {
        TextView t = new TextView(ui);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setPadding((int) (9 * dp), 0, (int) (9 * dp), 0);
        t.setOnClickListener(l);
        t.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, MATCH));
        return t;
    }

    private TextView tool(String label, View.OnClickListener l) {
        TextView t = new TextView(ui);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF37474F);
        g.setCornerRadius(6 * dp);
        t.setBackground(g);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, MATCH, 1f);
        int m = (int) (2 * dp);
        p.setMargins(m, m, m, m);
        t.setLayoutParams(p);
        return t;
    }

    private View buildResizeHandle() {
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(0xCCFFB300);
        View handle = new View(ui) {
            @Override
            protected void onDraw(Canvas c) {
                Path p = new Path();
                p.moveTo(getWidth(), 0);
                p.lineTo(getWidth(), getHeight());
                p.lineTo(0, getHeight());
                p.close();
                c.drawPath(p, paint);
            }
        };
        handle.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int sw, sh;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        sw = lp.width;
                        sh = lp.height;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        DisplayMetrics m = getResources().getDisplayMetrics();
                        lp.width = clamp(sw + (int) (e.getRawX() - sx),
                                (int) (220 * dp), m.widthPixels - lp.x);
                        lp.height = clamp(sh + (int) (e.getRawY() - sy),
                                (int) (160 * dp), m.heightPixels - lp.y);
                        wm.updateViewLayout(root, lp);
                        return true;
                    }
                    default:
                        return true;
                }
            }
        });
        return handle;
    }

    // ------------------------------------------------------------------ rendering mode

    /** Switches between hardware (GPU) and software drawing. Helps when the page shows black. */
    private void toggleRender() {
        softwareRender = !softwareRender;
        if (softwareRender) {
            lp.flags &= ~HW_ACCEL;
            web.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        } else {
            lp.flags |= HW_ACCEL;
            web.setLayerType(View.LAYER_TYPE_NONE, null);
        }
        renderButton.setText(softwareRender ? "SW" : "GPU");
        toast(softwareRender ? "Software drawing" : "GPU drawing");
        if (!minimized) {
            // this flag is only read when the window is created, so re-create it
            wm.removeView(root);
            wm.addView(root, lp);
        }
    }

    // ------------------------------------------------------------------ focus / keyboard

    /** The window ignores focus (so the app behind keeps it) until you touch the web page. */
    private void setWindowFocusable(boolean focusable) {
        if (root == null || lp == null || minimized) {
            return;
        }
        boolean current = (lp.flags & NOT_FOCUSABLE) == 0;
        if (current == focusable) {
            return;
        }
        if (focusable) {
            lp.flags &= ~NOT_FOCUSABLE;
        } else {
            lp.flags |= NOT_FOCUSABLE;
            imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        }
        wm.updateViewLayout(root, lp);
    }

    private void showKeyboardFor(final View target) {
        setWindowFocusable(true);
        target.requestFocus();
        root.postDelayed(new Runnable() {
            @Override
            public void run() {
                imm.showSoftInput(target, InputMethodManager.SHOW_IMPLICIT);
            }
        }, 150);
    }

    private void loadLinkFromClipboard() {
        setWindowFocusable(true);
        root.postDelayed(new Runnable() {
            @Override
            public void run() {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData d = cm.getPrimaryClip();
                String s = "";
                if (d != null && d.getItemCount() > 0) {
                    CharSequence t = d.getItemAt(0).coerceToText(FloatService.this);
                    if (t != null) {
                        s = t.toString().trim();
                    }
                }
                if (s.startsWith("https://")) {
                    web.loadUrl(s);
                } else {
                    toast("Copy a link that starts with https:// first");
                }
            }
        }, 150);
    }

    // ------------------------------------------------------------------ minimize / restore

    private void minimize() {
        if (minimized) {
            return;
        }
        CookieManager.getInstance().flush();
        web.onPause();
        web.pauseTimers();
        wm.removeView(root);
        minimized = true;

        int size = (int) (52 * dp);
        if (bubble == null) {
            bubble = new TextView(ui);
            bubble.setText("W");
            bubble.setTextColor(0xFFFFFFFF);
            bubble.setTextSize(20);
            bubble.setGravity(Gravity.CENTER);
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            gd.setColor(0xDD263238);
            gd.setStroke((int) (2 * dp), 0xFFFFB300);
            bubble.setBackground(gd);
            bubble.setOnTouchListener(new View.OnTouchListener() {
                float sx, sy;
                int ox, oy;
                boolean moved;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = e.getRawX();
                            sy = e.getRawY();
                            ox = bubbleLp.x;
                            oy = bubbleLp.y;
                            moved = false;
                            return true;
                        case MotionEvent.ACTION_MOVE: {
                            float dx = e.getRawX() - sx;
                            float dy = e.getRawY() - sy;
                            if (Math.abs(dx) > 10 * dp || Math.abs(dy) > 10 * dp) {
                                moved = true;
                            }
                            if (moved) {
                                bubbleLp.x = ox + (int) dx;
                                bubbleLp.y = oy + (int) dy;
                                wm.updateViewLayout(bubble, bubbleLp);
                            }
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                            if (!moved) {
                                bubble.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        restore();
                                    }
                                });
                            }
                            return true;
                        default:
                            return true;
                    }
                }
            });
        }
        bubbleLp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = Math.max(0, lp.x + lp.width - size);
        bubbleLp.y = lp.y;
        wm.addView(bubble, bubbleLp);
    }

    private void restore() {
        if (!minimized) {
            return;
        }
        wm.removeView(bubble);
        wm.addView(root, lp);
        minimized = false;
        web.onResume();
        web.resumeTimers();
    }

    // ------------------------------------------------------------------ cleanup

    @Override
    public void onDestroy() {
        try {
            if (root != null && root.isAttachedToWindow()) {
                wm.removeView(root);
            }
        } catch (RuntimeException ignored) {
            // window already gone
        }
        try {
            if (bubble != null && bubble.isAttachedToWindow()) {
                wm.removeView(bubble);
            }
        } catch (RuntimeException ignored) {
            // window already gone
        }
        if (web != null) {
            CookieManager.getInstance().flush();
            if (col != null) {
                col.removeAllViews();
            }
            web.destroy();
            web = null;
        }
        root = null;
        super.onDestroy();
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
