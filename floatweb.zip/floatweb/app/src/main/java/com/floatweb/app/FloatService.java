package com.floatweb.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A floating, movable, resizable browser window (overlay) with a minimize-to-bubble mode.
 * No libraries: only Android framework classes.
 */
public class FloatService extends Service {

    static final String ACTION_STOP = "com.floatweb.app.STOP";
    private static final String CHANNEL_ID = "floatweb";
    private static final String HOME_URL = "https://claude.ai/";
    private static final int NOT_FOCUSABLE = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;

    private Context ui;
    private WindowManager wm;
    private InputMethodManager imm;
    private float dp;

    private FrameLayout root;
    private LinearLayout col;
    private WebView web;
    private WindowManager.LayoutParams lp;

    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private boolean minimized = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(1, buildNotification());
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (root == null) {
            createWindow();
        }
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL_ID, "FloatWeb", NotificationManager.IMPORTANCE_MIN));
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("FloatWeb is running")
                .setContentText("Tap to close it")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    // ------------------------------------------------------------------ window

    private void createWindow() {
        ui = new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        dp = getResources().getDisplayMetrics().density;

        // Root container. It also watches taps outside the window to give focus back.
        root = new FrameLayout(ui) {
            @Override
            public boolean dispatchTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                    setWindowFocusable(false);
                }
                return super.dispatchTouchEvent(e);
            }
        };
        root.setBackgroundColor(0xFF1F1F1F);

        col = new LinearLayout(ui);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        col.addView(buildBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (int) (40 * dp)));

        web = buildWebView();
        col.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(buildResizeHandle(), new FrameLayout.LayoutParams(
                (int) (32 * dp), (int) (32 * dp), Gravity.BOTTOM | Gravity.END));

        DisplayMetrics m = getResources().getDisplayMetrics();
        lp = new WindowManager.LayoutParams(
                (int) (m.widthPixels * 0.92f),
                (int) (m.heightPixels * 0.45f),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (m.widthPixels * 0.04f);
        lp.y = 0;
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        wm.addView(root, lp);
        web.loadUrl(HOME_URL);
    }

    private WebView buildWebView() {
        WebView w = new WebView(ui);
        w.setBackgroundColor(0xFF1F1F1F);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String scheme = r.getUrl().getScheme();
                // keep web pages inside the window, ignore every other scheme
                return !("https".equals(scheme) || "http".equals(scheme));
            }
        });
        w.setWebChromeClient(new WebChromeClient());
        w.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    setWindowFocusable(true);
                }
                return false;
            }
        });
        return w;
    }

    private LinearLayout buildBar() {
        LinearLayout bar = new LinearLayout(ui);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF263238);

        TextView title = new TextView(ui);
        title.setText("  FloatWeb (drag)");
        title.setTextColor(0xFFB0BEC5);
        title.setTextSize(12);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        ox = lp.x;
                        oy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        DisplayMetrics m = getResources().getDisplayMetrics();
                        lp.x = clamp(ox + (int) (e.getRawX() - sx), 0, m.widthPixels - lp.width);
                        lp.y = clamp(oy + (int) (e.getRawY() - sy), 0, m.heightPixels - lp.height);
                        wm.updateViewLayout(root, lp);
                        return true;
                    }
                    default:
                        return true;
                }
            }
        });
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        bar.addView(button("<", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (web.canGoBack()) {
                    web.goBack();
                }
            }
        }));
        bar.addView(button("Home", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                web.loadUrl(HOME_URL);
            }
        }));
        bar.addView(button("Link", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadLinkFromClipboard();
            }
        }));
        bar.addView(button("KB", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showKeyboard();
            }
        }));
        bar.addView(button("\u2014", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                minimize();
            }
        }));
        bar.addView(button("X", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        }));
        return bar;
    }

    private TextView button(String label, View.OnClickListener l) {
        TextView t = new TextView(ui);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setPadding((int) (11 * dp), 0, (int) (11 * dp), 0);
        t.setOnClickListener(l);
        t.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return t;
    }

    private View buildResizeHandle() {
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(0xCCFFB300);
        View handle = new View(ui) {
            @Override
            protected void onDraw(Canvas c) {
                Path p = new Path();
                p.moveTo(getWidth(), 0);
                p.lineTo(getWidth(), getHeight());
                p.lineTo(0, getHeight());
                p.close();
                c.drawPath(p, paint);
            }
        };
        handle.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int sw, sh;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        sw = lp.width;
                        sh = lp.height;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        DisplayMetrics m = getResources().getDisplayMetrics();
                        lp.width = clamp(sw + (int) (e.getRawX() - sx),
                                (int) (220 * dp), m.widthPixels - lp.x);
                        lp.height = clamp(sh + (int) (e.getRawY() - sy),
                                (int) (160 * dp), m.heightPixels - lp.y);
                        wm.updateViewLayout(root, lp);
                        return true;
                    }
                    default:
                        return true;
                }
            }
        });
        return handle;
    }

    // ------------------------------------------------------------------ focus / keyboard

    /** The window ignores focus (so the app behind keeps it) until you touch the web page. */
    private void setWindowFocusable(boolean focusable) {
        if (root == null || lp == null || minimized) {
            return;
        }
        boolean current = (lp.flags & NOT_FOCUSABLE) == 0;
        if (current == focusable) {
            return;
        }
        if (focusable) {
            lp.flags &= ~NOT_FOCUSABLE;
        } else {
            lp.flags |= NOT_FOCUSABLE;
            imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        }
        wm.updateViewLayout(root, lp);
    }

    private void showKeyboard() {
        setWindowFocusable(true);
        web.requestFocus();
        root.postDelayed(new Runnable() {
            @Override
            public void run() {
                imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT);
            }
        }, 150);
    }

    private void loadLinkFromClipboard() {
        setWindowFocusable(true);
        root.postDelayed(new Runnable() {
            @Override
            public void run() {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData d = cm.getPrimaryClip();
                String s = "";
                if (d != null && d.getItemCount() > 0) {
                    CharSequence t = d.getItemAt(0).coerceToText(FloatService.this);
                    if (t != null) {
                        s = t.toString().trim();
                    }
                }
                if (s.startsWith("https://")) {
                    web.loadUrl(s);
                } else {
                    Toast.makeText(FloatService.this,
                            "Copy a link that starts with https:// first", Toast.LENGTH_SHORT).show();
                }
            }
        }, 150);
    }

    // ------------------------------------------------------------------ minimize / restore

    private void minimize() {
        if (minimized) {
            return;
        }
        CookieManager.getInstance().flush();
        web.onPause();
        web.pauseTimers();
        wm.removeView(root);
        minimized = true;

        int size = (int) (52 * dp);
        if (bubble == null) {
            bubble = new TextView(ui);
            bubble.setText("W");
            bubble.setTextColor(0xFFFFFFFF);
            bubble.setTextSize(20);
            bubble.setGravity(Gravity.CENTER);
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            gd.setColor(0xDD263238);
            gd.setStroke((int) (2 * dp), 0xFFFFB300);
            bubble.setBackground(gd);
            bubble.setOnTouchListener(new View.OnTouchListener() {
                float sx, sy;
                int ox, oy;
                boolean moved;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = e.getRawX();
                            sy = e.getRawY();
                            ox = bubbleLp.x;
                            oy = bubbleLp.y;
                            moved = false;
                            return true;
                        case MotionEvent.ACTION_MOVE: {
                            float dx = e.getRawX() - sx;
                            float dy = e.getRawY() - sy;
                            if (Math.abs(dx) > 10 * dp || Math.abs(dy) > 10 * dp) {
                                moved = true;
                            }
                            if (moved) {
                                bubbleLp.x = ox + (int) dx;
                                bubbleLp.y = oy + (int) dy;
                                wm.updateViewLayout(bubble, bubbleLp);
                            }
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                            if (!moved) {
                                bubble.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        restore();
                                    }
                                });
                            }
                            return true;
                        default:
                            return true;
                    }
                }
            });
        }
        bubbleLp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = Math.max(0, lp.x + lp.width - size);
        bubbleLp.y = lp.y;
        wm.addView(bubble, bubbleLp);
    }

    private void restore() {
        if (!minimized) {
            return;
        }
        wm.removeView(bubble);
        wm.addView(root, lp);
        minimized = false;
        web.onResume();
        web.resumeTimers();
    }

    // ------------------------------------------------------------------ cleanup

    @Override
    public void onDestroy() {
        try {
            if (root != null && root.isAttachedToWindow()) {
                wm.removeView(root);
            }
        } catch (RuntimeException ignored) {
            // window already gone
        }
        try {
            if (bubble != null && bubble.isAttachedToWindow()) {
                wm.removeView(bubble);
            }
        } catch (RuntimeException ignored) {
            // window already gone
        }
        if (web != null) {
            CookieManager.getInstance().flush();
            if (col != null) {
                col.removeAllViews();
            }
            web.destroy();
            web = null;
        }
        root = null;
        super.onDestroy();
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
