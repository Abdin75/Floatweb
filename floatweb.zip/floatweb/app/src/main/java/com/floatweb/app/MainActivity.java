package com.floatweb.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Asks for the "display over other apps" permission, then starts the floating window. */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (24 * dp);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        TextView text = new TextView(this);
        text.setText("FloatWeb needs permission to display over other apps.\n"
                + "Tap the button, enable it for FloatWeb, then come back.");
        text.setTextSize(16);
        box.addView(text);

        Button grant = new Button(this);
        grant.setText("Grant permission");
        grant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        box.addView(grant);

        setContentView(box);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this)) {
            startForegroundService(new Intent(this, FloatService.class));
            finish();
        }
    }
}
